using UnityEngine;
using System.Collections;

public class AttackCounterUpdate : MonoBehaviour {
	public int attackCounter = 10;
	float lastTickTime;
	

	// Use this for initialization
	void Start () {
		guiText.text = attackCounter.ToString();
		lastTickTime = Time.time;
	}
	
	// Update is called once per frame
	void Update () {
		float nowtime;
		if (attackCounter >0 && (nowtime=Time.time) - lastTickTime >= 1 ) {
			lastTickTime = nowtime;
			attackCounter --;
			guiText.text = attackCounter.ToString();
		}
	}
}