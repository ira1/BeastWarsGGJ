using UnityEngine;
using System.Collections.Generic;


public class Keyboard : MonoBehaviour {
	
	List<int> SelectedTags = new List<int>();
	public Transform QPrefab;
	public Transform QLocation;
	
	public Transform WPrefab;
	public Transform WLocation;

	public Transform EPrefab;
	public Transform ELocation;
	
	public SupplyCounterUpdate supply;

	public Vector3 RandomizeStarLocation = new Vector3(10,10,10);
	
	// Use this for initialization
	void Start () {
	
	}

	void ToggleSelect (int tag)
	{
		if (SelectedTags.Contains(tag))
			SelectedTags.Remove(tag);
		else
			SelectedTags.Add(tag);
	}
	
	// Update is called once per frame
	void Update () 
	{
		if (Input.GetKeyDown(KeyCode.Escape))
		{
			Application.LoadLevel(Application.loadedLevel);
		}
		if (Input.GetKeyDown(KeyCode.Space))
		{
			if (Time.timeScale>0)
				Time.timeScale=0;
			else 
				Time.timeScale=1;
		}
		if (Input.GetKeyDown(KeyCode.Alpha1))
		{
			ToggleSelect(1);
		}
	
		if (Input.GetKeyDown(KeyCode.Alpha2))
		{
			ToggleSelect(2);
		}

		if (Input.GetKeyDown(KeyCode.Alpha3))
		{
			ToggleSelect(3);
		}
		
		if (Input.GetKeyDown(KeyCode.Q))
		{
			if (supply && supply.supplyAvailable >= 1) {
				CreateAnimal(QPrefab, QLocation);			
				supply.supplyAvailable--;
				supply.guiText.text = supply.supplyAvailable.ToString();
			}
		}
		
		if (Input.GetKeyDown(KeyCode.W))
			if (supply && supply.supplyAvailable >= 2) {
				CreateAnimal(WPrefab, WLocation);
				supply.supplyAvailable-=2;
				supply.guiText.text = supply.supplyAvailable.ToString();
			}

		if (Input.GetKeyDown(KeyCode.E))
			if (supply && supply.supplyAvailable >= 3) {
				CreateAnimal(EPrefab, ELocation);
				supply.supplyAvailable-=3;
				supply.guiText.text = supply.supplyAvailable.ToString();
			}

		UpdateSelections();
		
	}

	void UpdateSelections ()
	{
		var selection_objects = GameObject.FindObjectsOfType(typeof(Selection));
		foreach( Selection selection in selection_objects)
		{
			selection.Selected = SelectedTags.Contains( selection.SelectionKey );
		}
	}

	void SelectAll (string tag)
	{
		Debug.Log("Selected " + tag);
		
		GameObject[] animals=GameObject.FindGameObjectsWithTag(tag);
		foreach(GameObject animal in animals)
		{
			animal.GetComponent<Selection>();
			Selection selection=animal.GetComponent<Selection>();
			selection.Selected=true;
		}
	}
	
	
	void CreateAnimal (Transform prefab, Transform location)
	{
		if (!prefab || !location)
			return;
		
		var animal = Instantiate(prefab) as Transform;
		
		Vector3 offset;
		offset.x = Random.Range(0, RandomizeStarLocation.x);
		offset.y = Random.Range(0, RandomizeStarLocation.y);
		offset.z = Random.Range(0, RandomizeStarLocation.z);
		
		
		animal.position = location.position + offset;
	}
}